import socket
import ssl
import time
import sys
import os

PORT = 8080
MAX_BUFFER_SIZE = 65535  
ONE_GB = 1024 * 1024 * 1024  # 1 GB
FIVE_HUNDRED_MB = 500 * 1024 * 1024  # 500 MB
PROGRESS_FILE = "client_progress.txt"  
MAX_RETRIES = 5  

def error(message):
    print(message, file=sys.stderr)
    sys.exit(1)

def save_progress(total_sent):
    with open(PROGRESS_FILE, "w") as f:
        f.write(str(total_sent))

def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return int(f.read())
    return 0

def connect_to_server(server_ip):
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.load_verify_locations(cafile="server.crt")  

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            secure_sock = context.wrap_socket(sock, server_hostname=server_ip)
            secure_sock.settimeout(10)  
            secure_sock.connect((server_ip, PORT))
            print(f"[INFO] Connected to server (Attempt {attempt})")
            return secure_sock
        except socket.error as e:
            print(f"[WARNING] Connection attempt {attempt} failed: {e}")
            time.sleep(2)  
    error("Max retries reached. Could not connect to server.")

def main():
    if len(sys.argv) != 5:
        error("Usage: python client.py <500/1000> <message_size> <method (0=streaming/1=stop-and-wait)> <server_ip>")

    data_size = ONE_GB if int(sys.argv[1]) == 1000 else FIVE_HUNDRED_MB

    buffer_size = int(sys.argv[2])
    if buffer_size <= 0 or buffer_size > MAX_BUFFER_SIZE:
        error("Invalid message size. Must be between 1 and 65535.")

    method = int(sys.argv[3])
    if method not in [0, 1]:
        error("Invalid method. Use 0 for Streaming or 1 for Stop-and-Wait.")

    server_ip = sys.argv[4]

    total_sent = load_progress()
    messages = 0

    buffer = b'A' * buffer_size

    start_time = time.time()

    while total_sent < data_size:
        secure_sock = connect_to_server(server_ip)  

        secure_sock.send(str(method).encode())

        try:
            while total_sent < data_size:
                bytes_sent = secure_sock.send(buffer)
                if bytes_sent <= 0:
                    error("Send failed")
                
                total_sent += bytes_sent
                messages += 1

                if total_sent % (buffer_size * 100) == 0:
                    save_progress(total_sent)

                if method == 1:
                    ack = secure_sock.recv(1)  
                    if not ack:
                        error("ACK failed")
        except (socket.error, ConnectionResetError):
            print("[ERROR] Connection lost! Retrying...")
            time.sleep(2)  
            continue  

        break  

    if method == 0:
        secure_sock.send(b'END')

    if method == 0:
        confirmation = secure_sock.recv(4)  
        if confirmation != b'DONE':
            error("Server did not confirm receipt of all data.")

    end_time = time.time()
    time_taken = end_time - start_time
    speed = (total_sent / (1024 * 1024)) / time_taken  

    print(f"Total transmission time: {time_taken:.2f} seconds")
    print(f"Total messages sent: {messages}")
    print(f"Total bytes sent: {total_sent}")
    print(f"Transfer speed: {speed:.2f} MB/s")

    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)

    secure_sock.close()

if __name__ == "__main__":
    main()




