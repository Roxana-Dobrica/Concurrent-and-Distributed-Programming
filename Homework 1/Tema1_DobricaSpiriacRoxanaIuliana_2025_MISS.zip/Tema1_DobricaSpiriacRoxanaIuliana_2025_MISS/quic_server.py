import asyncio
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import StreamDataReceived, ConnectionTerminated
from aioquic.asyncio import QuicConnectionProtocol, serve

class QuicServerProtocol(QuicConnectionProtocol):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.total_bytes_received = 0
        self.total_messages_received = 0
        self.total_bytes_expected = 0  

    def quic_event_received(self, event):
        if isinstance(event, StreamDataReceived):
            self.total_bytes_received += len(event.data)
            self.total_messages_received += 1
            self.total_bytes_expected += len(event.data)  
        elif isinstance(event, ConnectionTerminated):
            packet_loss = self.total_bytes_expected - self.total_bytes_received
            packet_loss_percentage = (packet_loss / self.total_bytes_expected) * 100 if self.total_bytes_expected > 0 else 0

            print(f"Server: Protocol: QUIC")
            print(f"Total Messages Received: {self.total_messages_received}")
            print(f"Total Bytes Received: {self.total_bytes_received}")
            print(f"Packet Loss: {packet_loss} bytes")
            print(f"Packet Loss Percentage: {packet_loss_percentage:.2f}%")

async def run_quic_server(host, port, certfile, keyfile):
    configuration = QuicConfiguration(is_client=False)
    configuration.load_cert_chain(certfile, keyfile)

    await serve(
        host=host,
        port=port,
        configuration=configuration,
        create_protocol=QuicServerProtocol,
    )
    print(f"QUIC server is running on {host}:{port}")

    await asyncio.Event().wait()  

if __name__ == "__main__":
    host = "127.0.0.1"
    port = 8080
    certfile = "server.crt"
    keyfile = "server.key"
    asyncio.run(run_quic_server(host, port, certfile, keyfile))



