import socket
import os
import sys
import time

PORT = 8080
MAX_BUFFER_SIZE = 65535
ONE_GB = 1024 * 1024 * 1024
FIVE_HUNDRED_MB = 500 * 1024 * 1024
PROGRESS_FILE = "client_udp_progress.txt"


def save_progress(total_sent):
    with open(PROGRESS_FILE, "w") as f:
        f.write(str(total_sent))


def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return int(f.read())
    return 0


def udp_client(server_ip, data_size, message_size, method):
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_address = (server_ip, PORT)

    total_sent = load_progress()
    messages = 0
    buffer = b'A' * message_size

    print(f"[INFO] Sending transfer method: {'Streaming' if method == 0 else 'Stop-and-Wait'}")
    client_socket.sendto(str(method).encode(), server_address)
    time.sleep(1)  

    start_time = time.time()

    while total_sent < data_size:
        try:
            client_socket.sendto(buffer, server_address)
            total_sent += len(buffer)
            messages += 1

            if total_sent % (message_size * 100) == 0:
                save_progress(total_sent)

            if method == 1:  
                client_socket.settimeout(2)
                try:
                    ack, _ = client_socket.recvfrom(3)  
                    if ack != b'ACK':
                        print("[ERROR] Invalid ACK received.")
                except socket.timeout:
                    print("[WARNING] ACK timeout, resending last packet...")
                    total_sent -= len(buffer) 
        except Exception as e:
            print(f"[ERROR] {e}")
            break

    client_socket.sendto(b'END', server_address)
    end_time = time.time()
    time_taken = end_time - start_time
    speed = (total_sent / (1024 * 1024)) / time_taken

    print(f"Total transmission time: {time_taken:.2f} seconds")
    print(f"Total messages sent: {messages}")
    print(f"Total bytes sent: {total_sent}")
    print(f"Transfer speed: {speed:.2f} MB/s")

    if os.path.exists(PROGRESS_FILE):
        os.remove(PROGRESS_FILE)
    
    client_socket.close()


if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python udp_client.py <500/1000> <message_size> <method (0=streaming/1=stop-and-wait)> <server_ip>")
        sys.exit(1)

    data_size = ONE_GB if int(sys.argv[1]) == 1000 else FIVE_HUNDRED_MB
    message_size = int(sys.argv[2])
    method = int(sys.argv[3])
    server_ip = sys.argv[4]

    udp_client(server_ip, data_size, message_size, method)
