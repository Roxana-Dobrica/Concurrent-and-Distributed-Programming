import asyncio
import time
from aioquic.quic.configuration import QuicConfiguration
from aioquic.asyncio import connect

async def quic_client(host, port, data_size, transfer_method):
    configuration = QuicConfiguration(is_client=True)
    configuration.verify_mode = False  

    async with connect(host, port, configuration=configuration) as connection:
        stream_id = connection._quic.get_next_available_stream_id()
        start_time = time.time()

        if transfer_method == 0:  # Streaming
            data = b"a" * data_size
            connection._quic.send_stream_data(stream_id, data, end_stream=True)
        elif transfer_method == 1:  # Stop-and-Wait
            chunk_size = 65535
            data = b"a" * data_size
            for i in range(0, len(data), chunk_size):
                chunk = data[i:i + chunk_size]
                connection._quic.send_stream_data(stream_id, chunk, end_stream=False)
                await asyncio.sleep(0.01)  

        connection.transmit()

        await asyncio.sleep(2)  

        end_time = time.time()
        total_time = end_time - start_time
        total_bytes_sent = data_size
        total_messages_sent = data_size // 65535 + (1 if data_size % 65535 != 0 else 0)
        transfer_speed = (total_bytes_sent / (1024 * 1024)) / total_time  

        print(f"Client: Total Transmission Time: {total_time:.2f} seconds")
        print(f"Total Messages Sent: {total_messages_sent}")
        print(f"Total Bytes Sent: {total_bytes_sent}")
        print(f"Transfer Speed: {transfer_speed:.2f} MB/s")

if __name__ == "__main__":
    import sys
    data_size = int(sys.argv[1]) * 1024 * 1024  
    transfer_method = int(sys.argv[3])
    host = sys.argv[4]
    port = int(sys.argv[5])
    asyncio.run(quic_client(host, port, data_size, transfer_method))


