import socket
import os
import time

PORT = 8080
MAX_BUFFER_SIZE = 65535
PROGRESS_FILE = "server_udp_progress.txt"


def save_progress(total_received):
    with open(PROGRESS_FILE, "w") as f:
        f.write(str(total_received))


def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return int(f.read())
    return 0


def udp_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind(("0.0.0.0", PORT))
    print(f"[INFO] UDP Server listening on port {PORT}...")

    while True:  
        total_received = 0
        messages_received = 0
        messages_expected = 0  
        method = None
        client_address = None
        start_time = time.time()

        print("[INFO] Ready to accept a new transfer...")

        while True:  
            data, addr = server_socket.recvfrom(MAX_BUFFER_SIZE)

            if method is None:  
                method = int(data.decode())
                client_address = addr
                print(f"[INFO] Transfer method: {'Streaming' if method == 0 else 'Stop-and-Wait'}")
                continue

            if data == b'END':  
                print("[INFO] Transfer complete.")
                break

            total_received += len(data)
            messages_received += 1
            messages_expected += 1

            if total_received % (MAX_BUFFER_SIZE * 100) == 0:
                save_progress(total_received)

            if method == 1:  
                server_socket.sendto(b'ACK', client_address)

        packet_loss = messages_expected - messages_received
        packet_loss_percentage = (packet_loss / messages_expected) * 100 if messages_expected > 0 else 0

        end_time = time.time()
        time_taken = end_time - start_time

        print(f"Protocol: UDP")
        print(f"Messages received: {messages_received}")
        print(f"Bytes received: {total_received}")
        print(f"Total time: {time_taken:.2f} seconds")
        print(f"Packet loss: {packet_loss} packets")
        print(f"Packet loss percentage: {packet_loss_percentage:.2f}%")

        if os.path.exists(PROGRESS_FILE):
            os.remove(PROGRESS_FILE)

        print("[INFO] Ready for the next transfer...")


if __name__ == "__main__":
    udp_server()






