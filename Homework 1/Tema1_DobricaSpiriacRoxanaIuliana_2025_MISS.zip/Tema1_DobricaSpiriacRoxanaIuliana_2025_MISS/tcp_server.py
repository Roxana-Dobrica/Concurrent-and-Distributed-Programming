import socket
import ssl
import sys
import os

PORT = 8080
MAX_BUFFER_SIZE = 65535  
PROGRESS_FILE = "server_progress.txt"  

def error(message):
    print(message, file=sys.stderr)
    sys.exit(1)

def save_progress(total_received):
    with open(PROGRESS_FILE, "w") as f:
        f.write(str(total_received))

def load_progress():
    if os.path.exists(PROGRESS_FILE):
        with open(PROGRESS_FILE, "r") as f:
            return int(f.read())
    return 0

def main():
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile="server.crt", keyfile="server.key")  

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server_socket.bind(('0.0.0.0', PORT))
        server_socket.listen(1)
    except socket.error as e:
        error(f"Socket error: {e}")

    secure_socket = context.wrap_socket(server_socket, server_side=True)

    print(f"Server listening on port {PORT}...")

    while True:
        try:
            client_socket, client_address = secure_socket.accept()
            print(f"Client connected: {client_address}")

            client_socket.settimeout(10)  

            method = int(client_socket.recv(1).decode())
            print(f"Transfer method: {'Streaming' if method == 0 else 'Stop-and-Wait'}")

            total_received = load_progress()  
            messages = 0

            while True:
                try:
                    data = client_socket.recv(MAX_BUFFER_SIZE)
                    if not data or data == b'END':  
                        print("Client closed the connection.")
                        break

                    total_received += len(data)
                    messages += 1

                    if total_received % (MAX_BUFFER_SIZE * 100) == 0:
                        save_progress(total_received)

                    if method == 1:
                        client_socket.send(b'A')  
                except ConnectionResetError:
                    print("Client disconnected abruptly.")
                    break
                except socket.timeout:
                    print("Connection timed out.")
                    break
                except Exception as e:
                    print(f"An error occurred: {e}")
                    break

            if method == 0:
                client_socket.send(b'DONE')

            print(f"Protocol: TCP")
            print(f"Messages received: {messages}")
            print(f"Bytes received: {total_received}")

            if os.path.exists(PROGRESS_FILE):
                os.remove(PROGRESS_FILE)

            client_socket.close()
            print("Client disconnected. Waiting for new connection...")
        except socket.error as e:
            print(f"Socket error: {e}")

if __name__ == "__main__":
    main()




