## Deployment Instructions

### Pre-deployment Steps

Before deploying, **copy** the file `homework2pcd-60294a7b6458.json` to the `chat-pcd` folder. **Do not forget to remove it afterward** so it isn’t committed to the repository.

### Local Deployment

To build and run the backend locally, use the following commands. Replace `<service_account.json>` with your actual service account JSON file:

```bash
docker build -t local-backend .
docker run -v <service_account.json>:/app/credentials.json -e GOOGLE_APPLICATION_CREDENTIALS=/app/credentials.json -p 8080:8080 local-backend
```

### Cloud Deployment

Use the following commands to deploy the application to Google Cloud Run:
```bash
gcloud builds submit --tag gcr.io/homework2pcd/backend
gcloud run deploy backend --image gcr.io/homework2pcd/backend --platform managed --region europe-central2 --allow-unauthenticated
```

[//]: # (Summary)

[//]: # (This project demonstrates a modular architecture combining cloud-native services, an on-premise monitoring component, and serverless functions. The on-premise application ensures that only active chat metrics are stored, facilitating real-time system observability and performance optimization.)

[//]: # ()
[//]: # (Enjoy using and exploring the project!)