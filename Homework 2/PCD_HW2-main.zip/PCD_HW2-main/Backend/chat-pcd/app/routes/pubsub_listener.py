import json
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from google.cloud import pubsub_v1

from app import socketio

EMAIL_HOST = "smtp.gmail.com"
EMAIL_PORT = 587
EMAIL_ADDRESS = "alexxdominte@gmail.com"
EMAIL_PASSWORD = "akgy vfcs mduu vicb"


def send_email_notification(to_email, message_content):
    subject = "New Chat Message Notification"
    body = f"You have received a new message:\n\n{message_content}"

    msg = MIMEMultipart()
    msg["Bcc"] = EMAIL_ADDRESS
    msg["From"] = EMAIL_ADDRESS
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:

            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.sendmail(EMAIL_ADDRESS, to_email, msg.as_string())
        print(f"Email sent to {to_email}")
    except Exception as e:
        print(f"Error sending email: {e}")


subscriber = pubsub_v1.SubscriberClient()
subscription_path = subscriber.subscription_path("homework2pcd", "chat-subscription")


def callback(message):
    print(f"Received message: {message.data.decode('utf-8')}")

    message_data = json.loads(message.data.decode("utf-8"))
    user_id = message_data.get("user_id")
    message_content = message_data.get("message")

    user_email = message_data.get("email")
    if user_email:
        send_email_notification(user_email, message_content)

    message.ack()


def start_pubsub_listener():
    subscriber.subscribe(subscription_path, callback=callback)
    print("Listening for Pub/Sub messages...")


socketio.start_background_task(target=start_pubsub_listener)