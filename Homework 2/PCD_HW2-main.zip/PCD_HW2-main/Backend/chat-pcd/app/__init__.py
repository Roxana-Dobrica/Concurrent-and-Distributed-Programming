from flask import Flask
from flask_cors import CORS
from flask_socketio import SocketIO
from google.cloud import storage, firestore

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="eventlet")

# Initialize Firestore and Cloud Storage clients
db = firestore.Client()
storage_client = storage.Client()
BUCKET_NAME = 'image_bucket12345'
bucket = storage_client.get_bucket(BUCKET_NAME)

# Register Blueprints
from .routes.chat import chat_bp
from .routes.users import users_bp

app.register_blueprint(chat_bp, url_prefix='/chat')
app.register_blueprint(users_bp, url_prefix='/users')

# Initialize Pub/Sub listener
from .routes import pubsub_listener

pubsub_listener.start_pubsub_listener()