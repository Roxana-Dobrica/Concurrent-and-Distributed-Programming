import './Register.css'
import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import apiClient from "../api/ApiClient.ts";

const Register = () => {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState<string>('');  

    const navigate = useNavigate();

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();

        if (password !== confirmPassword) {
            setError("Passwords do not match");
            return;
        }

        const userData = { username, email, password };

        try {
            const response = await apiClient.post('/users/signup', userData);
            if (response.status === 201) {
                console.log("Registration successful");
                navigate('/login');
            }
        } catch (error) {
            if (axios.isAxiosError(error)) {
                setError(error.response?.data?.error || "Something went wrong");
            } else {
                setError("An unknown error occurred.");
            }
            console.error("Registration failed", error);
        }
    };

    return (
        <div className="register-container">
            <h1 className="register-title">Register</h1>
            <p>Please fill in the details to create an account.</p>
            <form className="register-form" onSubmit={handleSubmit}> 
                <label htmlFor="username">Username:</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                />
                <label htmlFor="email">Email:</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <label htmlFor="password">Password:</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                />
                <label htmlFor="confirm-password">Confirm Password:</label>
                <input
                    type="password"
                    id="confirm-password"
                    name="confirm-password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                />
                <button className="register-button" type="submit">Register</button>  
                {error && <p className="error-message">{error}</p>}  
            </form>
            <p className="change-login-page">Already have an account? <Link to="/login">Login here</Link></p>
        </div>
    );
};

export default Register;