import "./Chat.css";
import {useEffect, useRef, useState} from "react";
import io from "socket.io-client";
import {useNavigate, useParams} from "react-router-dom";
import dayjs from "dayjs";
import apiClient from "../api/ApiClient.ts";

const socket = io("wss://backend-1002823607746.europe-central2.run.app");
// const socket = io("http://127.0.0.1:8080");

const Chat = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const [chats, setChats] = useState<any[]>([]);
  const [messages, setMessages] = useState<any[]>([]);
  const [message, setMessage] = useState("");
  const userId = localStorage.getItem("userId");

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    fetchUserChats();
    fetchMessages();

    socket.emit("join_room", { room_id: roomId });

    socket.on("new_message", (newMessage) => {
      setMessages((prevMessages) => [...prevMessages, newMessage]);
    });

    return () => {
      socket.emit("leave_room", { room_id: roomId });
      socket.off("new_message");
    };
  }, [roomId]);

  // Delay to allow images to load before scrolling to bottom
  useEffect(() => {
    const scrollToBottom = () => {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 200);
    };

    const images = document.querySelectorAll(
        ".message-image"
    ) as NodeListOf<HTMLImageElement>;
    let loadedCount = 0;

    if (images.length === 0) {
      scrollToBottom();
      return;
    }

    images.forEach((img) => {
      if (img.complete) {
        loadedCount++;
      } else {
        img.onload = () => {
          loadedCount++;
          if (loadedCount === images.length) {
            scrollToBottom();
          }
        };
      }
    });

    scrollToBottom();
  }, [messages]);


  // Use Enter key to send message
  const onTextBoxKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter" && message.trim()) {
      handleSendMessage();
    }
  };

  const fetchUserChats = async () => {
    try {
      const response = await apiClient.get(
          `/chat/get_user_chats/${userId}`,
      )
      setChats(response.data);
    } catch (error) {
      console.error("Error fetching chats:", error);
    }
  };

  const fetchMessages = async () => {
    try {
        const response = await apiClient.get(
            `/chat/get_messages/${roomId}`,
        );
      setMessages(response.data);
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const handleSendMessage = () => {
    if (message.trim()) {
      const timestamp = new Date().toISOString();
      const email = localStorage.getItem("email");
      const messageData = {
        user_id: userId,
        room_id: roomId,
        message: message,
        timestamp: timestamp,
        email: email,
      };

      socket.emit("send_message", messageData);

      setMessage("");
    }
  };

  const handleFileChange = async (
      event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await apiClient.post(
            "/chat/upload",
            formData,
            {
                headers: { "Content-Type": "multipart/form-data" },
            }
        );

      if (response.data.file_url) {
        const messageData = {
          user_id: userId,
          room_id: roomId,
          file_url: response.data.file_url,
          message: "",
        };

        socket.emit("send_message", messageData);
      }
    } catch (error) {
      console.error("Error uploading file:", error);
    }
  };

  return (
      <div className="chat-container">
        <div className="sidebar">
          <h2>Chats</h2>
          <ul>
            {chats.map((chat) => (
                <li
                    key={chat.room_id}
                    onClick={() => navigate(`/chat/${chat.room_id}`)}
                >
                  {chat.room_id}
                </li>
            ))}
          </ul>
        </div>

        <div className="chat-section">
          <div className="messages">
            {messages.map((msg, index) => {
              const otherUser = chats.find(
                  (chat) => chat.room_id === roomId && chat.user_id !== userId
              );
              const otherUserName = otherUser
                  ? otherUser.participant_name
                  : "Partner";

              const formattedTimestamp = dayjs(msg.timestamp).format(
                  "DD/MM/YYYY, HH:mm"
              );

              return (
                  <div
                      key={index}
                      className={
                        msg.user_id === userId
                            ? "message-container-sent"
                            : "message-container-received"
                      }
                  >
                    <div
                        className={
                          msg.user_id === userId ? "sender-name" : "receiver-name"
                        }
                    >
                      {msg.user_id === userId ? "You" : otherUserName}
                    </div>

                    <div
                        className={
                          msg.user_id === userId ? "message sent" : "message received"
                        }
                    >
                      {msg.file_url ? (
                          <img
                              className="message-image"
                              src={msg.file_url}
                              alt="sent-img"
                          />
                      ) : (
                          msg.message
                      )}
                    </div>
                    <div
                        className={`message-timestamp ${
                            msg.user_id === userId
                                ? "timestamp-right"
                                : "timestamp-left"
                        }`}
                    >
                      {formattedTimestamp}
                    </div>
                  </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          <div className="message-input">
            <input
                type="text"
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(event) => onTextBoxKeyPress(event)}
            />
            <div className="send-message-section">
              <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  style={{ display: "none" }}
                  id="file-input"
              />
              <label htmlFor="file-input">
                <img
                    src="/assets/images/attach-file.png"
                    alt="Attachment"
                    className="attachment-icon"
                />
              </label>
              <img
                  src="/assets/images/send-message.png"
                  alt="Send"
                  className="send-message-icon"
                  onClick={handleSendMessage}
              />
            </div>
          </div>
        </div>
      </div>
  );
};

export default Chat;