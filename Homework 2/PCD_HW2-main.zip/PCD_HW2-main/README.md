# Real-Time Chat Application

In this project, we developed a real-time chat application that allows users to communicate instantly. The system supports conversations between two or more friends and ensures low-latency messaging using WebSockets. Unlike traditional HTTP requests, WebSockets enable a persistent connection between clients and the server, making it ideal for instant messaging applications.  

## Architecture Overview

The system is composed of three main components:
- **Native Cloud services**: We use Firestore for message storage, Cloud Storage for media files, and Pub/Sub for event-driven messaging.  
- **On-premise application**: A metrics aggregation service that collects and stores chat performance data in BigQuery for analysis.  
- **FaaS (Function as a Service)**: A Sentiment Analysis function that processes messages and classifies emotions in real time.

## URLs
- [Backend](https://backend-1002823607746.europe-central2.run.app)
- [Frontend](https://frontend-dot-homework2pcd.lm.r.appspot.com/)