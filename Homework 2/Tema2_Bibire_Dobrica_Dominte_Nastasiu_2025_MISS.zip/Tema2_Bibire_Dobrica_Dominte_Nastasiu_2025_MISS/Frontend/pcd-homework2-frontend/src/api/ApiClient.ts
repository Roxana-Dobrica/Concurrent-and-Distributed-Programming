import axios, {AxiosInstance} from 'axios';

// Create an Axios instance
const apiClient: AxiosInstance = axios.create({
    baseURL: 'https://backend-1002823607746.europe-central2.run.app',
    // baseURL: 'http://localhost:8080',
    headers: {
        'Content-Type': 'application/json',
    },
});

export default apiClient;