import './Login.css';
import * as React from 'react';
import {useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import axios from 'axios';
import apiClient from "../api/ApiClient.ts";

const Login = () => {
    const [username, setUsername] = useState<string>('');
    const [password, setPassword] = useState<string>('');
    const [error, setError] = useState<string>('');  
    const navigate = useNavigate();  
  
    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      
      const userData = { username, password };
      
      try {
        const response = await apiClient.post('/users/signin', userData);

        if (response.status === 200) {
          console.log("Login successful");
  
          const { user_id } = response.data;
          localStorage.setItem('userId', user_id);
  
          navigate('/chat');  
        }
      } catch (error) {
        if (axios.isAxiosError(error)) {
          setError(error.response?.data?.error || "Something went wrong");
        } else {
          setError("An unknown error occurred.");
        }
        console.error("Login failed", error);
      }
    }
  
    return (
      <div className="login-container">
        <h1 className="login-title">Login</h1>
        <p>Please enter your credentials to log in.</p>
        <form className="login-form" onSubmit={handleSubmit}>
          <label htmlFor="username">Username:</label>
          <input
            type="text"
            id="username"
            name="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button className="login-button" type="submit">Login</button>  
          {error && <p className="error-message">{error}</p>}
        </form>
        <p className="change-register-page">Don't have an account? <Link to="/register">Register here</Link></p>
      </div>
    );
  };
  
  export default Login;