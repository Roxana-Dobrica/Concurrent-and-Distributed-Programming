import traceback

import bcrypt
from flask import Blueprint, request, jsonify, current_app

from app import db

users_bp = Blueprint('users', __name__)

def get_user_data_by_id(user_id):
    """Retrieve user data given a Firestore document ID."""
    try:
        user_ref = db.collection('users').document(user_id).get()
        if user_ref.exists:
            return user_ref.to_dict()
        return None
    except Exception as e:
        current_app.logger.error("Error retrieving user by id %s: %s", user_id, str(e))
        return None

def get_user_data_by_username(username):
    """Retrieve user data (and document ID) for a given username."""
    try:
        users_ref = db.collection('users')
        query = users_ref.where('username', '==', username).limit(1)
        for doc in query.stream():
            return doc.to_dict(), doc.id
        return None, None
    except Exception as e:
        current_app.logger.error("Error retrieving user by username %s: %s", username, str(e))
        return None, None

@users_bp.route('/signin', methods=['POST'])
def signin():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')

        if not username or not password:
            return jsonify({'error': 'Username and password are required'}), 400

        user_data, user_doc_id = get_user_data_by_username(username)
        if not user_data:
            return jsonify({'error': 'User not found'}), 404

        stored_password_hash = user_data.get('password')
        if bcrypt.checkpw(password.encode('utf-8'), stored_password_hash.encode('utf-8')):
            return jsonify({'message': 'Sign-in successful', 'user_id': user_doc_id}), 200
        else:
            return jsonify({'error': 'Invalid credentials'}), 401
    except Exception as e:
        current_app.logger.error("Unhandled exception in signin: %s\n%s", str(e), traceback.format_exc())
        return jsonify({'error': 'Internal server error in signin'}), 500

@users_bp.route('/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        email = data.get('email')

        if not username or not password or not email:
            return jsonify({'error': 'All fields are required'}), 400

        # Check if the username already exists
        existing_user, _ = get_user_data_by_username(username)
        if existing_user:
            return jsonify({'error': 'Username already exists'}), 400

        password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        users_ref = db.collection('users')
        new_user_ref = users_ref.document()  # Auto-generated document ID
        new_user_ref.set({
            'username': username,
            'password': password_hash,
            'email': email
        })

        return jsonify({'message': 'User created successfully', 'user_id': new_user_ref.id}), 201
    except Exception as e:
        current_app.logger.error("Unhandled exception in signup: %s\n%s", str(e), traceback.format_exc())
        return jsonify({'error': 'Internal server error in signup'}), 500
