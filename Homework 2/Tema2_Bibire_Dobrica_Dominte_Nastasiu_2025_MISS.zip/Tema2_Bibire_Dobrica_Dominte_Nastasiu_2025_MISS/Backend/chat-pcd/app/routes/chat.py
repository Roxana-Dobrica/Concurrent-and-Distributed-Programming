import json
import time
import traceback
from datetime import datetime, timedelta, timezone

from flask import Blueprint, request, jsonify, current_app
from flask_socketio import emit, join_room, leave_room
from google.cloud import pubsub_v1
from werkzeug.utils import secure_filename

from app import db, bucket, socketio
from app.routes.users import get_user_data_by_id

# Create Blueprint
chat_bp = Blueprint('chat', __name__)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}


def allowed_file(filename):
    try:
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
    except Exception as e:
        current_app.logger.error("allowed_file error: %s", str(e))
        return False


def generate_signed_url(file_url):
    """Helper to generate a signed URL for media messages."""
    try:
        blob = bucket.blob(file_url)
        return blob.generate_signed_url(expiration=timedelta(hours=1), method='GET')
    except Exception as e:
        current_app.logger.error("Error generating signed URL: %s", str(e))
        return None


def save_message_to_firestore(room_id, message_data):
    """Helper to save a message in Firestore."""
    try:
        db.collection('chats').document(room_id).collection('messages').add(message_data)
    except Exception as e:
        raise Exception("Failed to save message: " + str(e))


# --------------------------------------------------------------------
# Global in-memory metrics storage

# Stores per-room aggregated metrics:
# {
#   room_id: {
#       'total_messages': int,
#       'total_latency': float,
#       'error_count': int,
#       'message_count_for_latency': int,
#       'last_reset': datetime
#   },
#   ...
# }
aggregated_metrics = {}

def update_aggregated_metrics(room_id, latency=0.0, error=False):
    if room_id not in aggregated_metrics:
        aggregated_metrics[room_id] = {
            'total_messages': 0,
            'total_latency': 0.0,
            'error_count': 0,
            'message_count_for_latency': 0,
            'last_reset': datetime.now(timezone.utc)
        }
    aggregated_metrics[room_id]['total_messages'] += 1
    if error:
        aggregated_metrics[room_id]['error_count'] += 1
    else:
        aggregated_metrics[room_id]['total_latency'] += latency
        aggregated_metrics[room_id]['message_count_for_latency'] += 1


# Global in-memory session storage.
# Here we use the Socket.IO session ID as the unique user identifier.
active_sessions = {}  # { session_id: { "user_id": session_id, "rooms": set([...]) } }

@socketio.on('connect')
def handle_connect():
    session_id = request.sid
    # Create an active session using the session_id as the user identifier.
    active_sessions[session_id] = {"user_id": session_id, "rooms": set()}
    current_app.logger.info(f'Client connected with session: {session_id}')

@socketio.on('disconnect')
def handle_disconnect():
    session_id = request.sid
    # Remove the session from active_sessions.
    active_sessions.pop(session_id, None)
    current_app.logger.info(f'Client disconnected with session: {session_id}')

@socketio.on('join_room')
def handle_join_room(data):
    room_id = data.get('room_id')
    session_id = request.sid
    if not room_id:
        emit('error', {'error': 'Invalid room ID'})
        return
    join_room(room_id)
    current_app.logger.info('Client joined room: %s', room_id)
    # Ensure an active session exists and update the room membership.
    if session_id not in active_sessions:
        active_sessions[session_id] = {"user_id": session_id, "rooms": set()}
    active_sessions[session_id]["rooms"].add(room_id)
    emit('room_joined', {'room_id': room_id})

@socketio.on('leave_room')
def handle_leave_room(data):
    room_id = data.get('room_id')
    session_id = request.sid
    if not room_id:
        emit('error', {'error': 'Invalid room ID'})
        return
    leave_room(room_id)
    current_app.logger.info('Client left room: %s', room_id)
    # Remove the room from the session info.
    if session_id in active_sessions:
        active_sessions[session_id]["rooms"].discard(room_id)
    emit('room_left', {'room_id': room_id})

# --------------------------------------------------------------------
# Metrics Endpoint

@chat_bp.route('/metrics', methods=['GET'])
def get_metrics():
    """
    Aggregates chat metrics per room and computes:
      - Active users (counted from active_sessions)
      - Total messages
      - Average latency (in seconds)
      - Error count
      - Throughput (messages per second)
    Resets the counters after generating the report.
    """
    now = datetime.now(timezone.utc)
    results = {}

    # Compute active users per room by iterating through active_sessions.
    active_users_per_room = {}
    for session in active_sessions.values():
        for room in session["rooms"]:
            active_users_per_room[room] = active_users_per_room.get(room, 0) + 1

    # Aggregate metrics per room.
    for room_id, data in aggregated_metrics.items():
        total_messages = data.get('total_messages', 0)
        total_latency = data.get('total_latency', 0.0)
        error_count = data.get('error_count', 0)
        count_for_latency = data.get('message_count_for_latency', 0)
        avg_latency = total_latency / count_for_latency if count_for_latency > 0 else 0.0

        # Compute throughput based on elapsed time.
        elapsed_seconds = (now - data.get('last_reset', now)).total_seconds()
        throughput = total_messages / elapsed_seconds if elapsed_seconds > 0 else 0.0

        active_count = active_users_per_room.get(room_id, 0)
        results[room_id] = {
            "timestamp": now.isoformat(),
            "chat_room": room_id,
            "active_users": active_count,
            "total_messages": total_messages,
            "avg_latency": avg_latency,
            "error_count": error_count,
            "throughput": throughput
        }

    # Reset the metrics for a new aggregation period.
    for room_id in aggregated_metrics.keys():
        aggregated_metrics[room_id] = {
            'total_messages': 0,
            'total_latency': 0.0,
            'error_count': 0,
            'message_count_for_latency': 0,
            'last_reset': now
        }

    return jsonify(results)

# --------------------------------------------------------------------
# Existing Endpoints and SocketIO Handlers

@chat_bp.route('/upload', methods=['POST'])
def upload_file():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part in the request'}), 400

        file = request.files['file']
        if not file or file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed'}), 400

        filename = secure_filename(file.filename)
        blob_path = f"media/{filename}"
        blob = bucket.blob(blob_path)
        try:
            blob.upload_from_file(file, content_type=file.content_type)
        except Exception as e:
            current_app.logger.error("Error uploading file: %s", str(e))
            return jsonify({'error': 'Failed to upload file'}), 500

        return jsonify({'file_url': blob_path}), 200
    except Exception as e:
        current_app.logger.error("Unhandled exception in upload_file: %s\n%s", str(e), traceback.format_exc())
        return jsonify({'error': 'Internal server error'}), 500


@chat_bp.route('/get_messages/<room_id>', methods=['GET'])
def get_messages(room_id):
    if not room_id:
        return jsonify({'error': 'No room ID provided'}), 400

    try:
        messages_ref = db.collection('chats').document(room_id).collection('messages')
        messages = messages_ref.order_by("timestamp").stream()
    except Exception as e:
        current_app.logger.error("Error retrieving messages: %s", str(e))
        return jsonify({'error': 'Failed to retrieve messages'}), 500

    message_list = []
    try:
        for msg in messages:
            data = msg.to_dict()
            if data.get('type') == 'media' and data.get('file_url'):
                signed_url = generate_signed_url(data['file_url'])
                data['file_url'] = signed_url
            message_list.append(data)
    except Exception as e:
        current_app.logger.error("Error processing messages: %s", str(e))
        return jsonify({'error': 'Failed to process messages'}), 500

    return jsonify(message_list)

project_id = "homework2pcd"
topic_id = "chat-messages"

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(project_id, topic_id)


@socketio.on('send_message')
def handle_send_message(data):
    start_time = time.time()
    try:
        user_id = data.get('user_id')
        room_id = data.get('room_id')
        message = data.get('message', '')
        file_url = data.get('file_url')  # If provided, it's a media message
        timestamp = datetime.now().strftime('%m/%d/%Y, %H:%M:%S')

        if not user_id or not isinstance(user_id, str):
            emit('error', {'error': 'Invalid user ID'})
            return
        if not room_id or not isinstance(room_id, str):
            emit('error', {'error': 'Invalid room ID'})
            return

        if not file_url:
            if not message or not isinstance(message, str) or not message.strip():
                emit('error', {'error': 'Invalid message'})
                return
            if len(message) > 500:
                emit('error', {'error': 'Message exceeds maximum length of 500 characters'})
                return
        else:
            if not isinstance(file_url, str) or not allowed_file(file_url):
                emit('error', {'error': 'Invalid file URL or file type'})
                return

        user_data = get_user_data_by_id(user_id)
        if not user_data:
            emit('error', {'error': 'User not found'})
            return

        username = user_data.get('username')
        email = user_data.get('email')

        message_data = {
            'user_id': user_id,
            'username': username,
            'room_id': room_id,
            'message': message,
            'timestamp': timestamp,
            'email': email,
            'type': 'media' if file_url else 'text'
        }
        if file_url:
            message_data['file_url'] = file_url

        message_json = json.dumps(message_data)
        print(f"Publishing message to topic: {topic_path}")

        try:
            future = publisher.publish(topic_path, message_json.encode("utf-8"))
            message_id = future.result()
            print(f"Message published with ID: {message_id}")
        except Exception as e:
            print(f"Failed to publish message: {str(e)}")

        try:
            save_message_to_firestore(room_id, message_data)
        except Exception as e:
            current_app.logger.error("Firestore error: %s", str(e))
            emit('error', {'error': 'Failed to save message'})
            update_aggregated_metrics(room_id, error=True)
            return

        if file_url:
            signed_url = generate_signed_url(file_url)
            message_data['file_url'] = signed_url

        emit('new_message', message_data, room=room_id)
        latency = time.time() - start_time
        update_aggregated_metrics(room_id, latency=latency, error=False)
    except Exception as e:
        current_app.logger.error("Unhandled exception in send_message: %s\n%s", str(e), traceback.format_exc())
        emit('error', {'error': 'Internal server error in send_message'})
        if 'room_id' in data:
            update_aggregated_metrics(data.get('room_id'), error=True)


@socketio.on('send_media_message')
def handle_send_media_message(data):
    start_time = time.time()
    try:
        user_id = data.get('user_id')
        room_id = data.get('room_id')
        message = data.get('message')
        file_url = data.get('file_url')
        timestamp = datetime.now().strftime('%m/%d/%Y, %H:%M:%S')

        if user_id and room_id and file_url:
            message_data = {
                'user_id': user_id,
                'room_id': room_id,
                'message': message,
                'file_url': file_url,
                'timestamp': timestamp,
                'type': 'media'
            }
            save_message_to_firestore(room_id, message_data)
            signed_url = generate_signed_url(file_url)
            message_data['file_url'] = signed_url
            emit('new_message', message_data, room=room_id)
            latency = time.time() - start_time
            update_aggregated_metrics(room_id, latency=latency, error=False)
        else:
            emit('error', {'error': 'Invalid media message data'})
            update_aggregated_metrics(room_id, error=True)
    except Exception as e:
        current_app.logger.error("Unhandled exception in send_media_message: %s\n%s", str(e), traceback.format_exc())
        emit('error', {'error': 'Internal server error in send_media_message'})
        if 'room_id' in data:
            update_aggregated_metrics(data.get('room_id'), error=True)


@chat_bp.route('/create_chat', methods=['POST'])
def create_chat():
    try:
        data = request.get_json()
        users = data.get('users')  # expecting a list of user IDs
        if not users or not isinstance(users, list) or len(users) < 2:
            return jsonify({'error': 'At least two user IDs are required'}), 400

        new_room_ref = db.collection('chats').document()
        new_room_ref.set({
            'users': users,
            'created_at': datetime.now().strftime('%m/%d/%Y, %H:%M:%S')
        })
        return jsonify({'room_id': new_room_ref.id}), 201
    except Exception as e:
        current_app.logger.error("Error in create_chat: %s\n%s", str(e), traceback.format_exc())
        return jsonify({'error': 'Internal server error in create_chat'}), 500


@chat_bp.route('/get_user_chats/<user_id>', methods=['GET'])
def get_user_chats(user_id):
    if not user_id or not isinstance(user_id, str):
        return jsonify({'error': 'Invalid user ID'}), 400

    try:
        chats_ref = db.collection('chats')
        user_chats = chats_ref.where('users', 'array_contains', user_id).stream()
    except Exception as e:
        current_app.logger.error("Error retrieving user chats: %s", str(e))
        return jsonify({'error': 'Failed to retrieve user chats'}), 500

    chat_list = []
    try:
        for chat in user_chats:
            chat_data = chat.to_dict()
            chat_data['room_id'] = chat.id

            participants_ids = chat_data.get('users', [])
            participants = []
            for uid in participants_ids:
                try:
                    user_data = get_user_data_by_id(uid)
                    participants.append(user_data.get('username', 'Unknown') if user_data else 'Unknown')
                except Exception as ex:
                    current_app.logger.error("Error retrieving user data for %s: %s", uid, str(ex))
                    participants.append('Unknown')
            chat_data['participants'] = participants
            chat_list.append(chat_data)
    except Exception as e:
        current_app.logger.error("Error processing user chats: %s", str(e))
        return jsonify({'error': 'Failed to process user chats'}), 500

    return jsonify(chat_list)