import requests
from apscheduler.schedulers.blocking import BlockingScheduler
from google.cloud import bigquery

# Configuration
CHAT_METRICS_URL = "https://backend-1002823607746.europe-central2.run.app/chat/metrics"
# CHAT_METRICS_URL = "http://127.0.0.1:8080/chat/metrics"

# Create a BigQuery client and reference to the table
bq_client = bigquery.Client()
dataset_id = "chat_analytics"
table_id = "chat_performance_metrics"
table_ref = f"homework2pcd.{dataset_id}.{table_id}"

print("BigQuery Table Reference:", table_ref)

def fetch_metrics():
    """
    Fetches aggregated metrics from the chat backend's /chat/metrics endpoint.
    Expects a JSON response with keys as room IDs and values as metrics.
    """
    try:
        response = requests.get(CHAT_METRICS_URL, timeout=10)
        response.raise_for_status()
        metrics = response.json()
        print()
        print("--" * 50)
        print(f"Fetched metrics: {metrics}")
        return metrics
    except Exception as e:
        print(f"Error fetching metrics: {e}")
        return None

def insert_metric_row(metric):
    """
    Inserts a single metric row into BigQuery.
    The metric argument should be a dictionary matching your schema:
      - timestamp (TIMESTAMP)
      - chat_room (STRING)
      - active_users (INTEGER)
      - total_messages (INTEGER)
      - avg_latency (FLOAT)
      - error_count (INTEGER)
      - throughput (FLOAT)
    """
    row = {
        "timestamp": metric.get("timestamp"),
        "chat_room": metric.get("chat_room"),
        "active_users": metric.get("active_users"),
        "total_messages": metric.get("total_messages"),
        "avg_latency": metric.get("avg_latency"),
        "error_count": metric.get("error_count"),
        "throughput": metric.get("throughput")
    }
    print("Inserting row:", row)
    errors = bq_client.insert_rows_json(table_ref, [row])
    if not errors:
        print(f"Inserted metrics for room {metric.get('chat_room')}")
    else:
        print(f"Errors inserting metrics for room {metric.get('chat_room')}: {errors}")

def flush_metrics_to_bigquery():
    """
    Fetches metrics from the chat backend and inserts each room's metrics into BigQuery.
    Only metrics for rooms with active users (active_users > 0) are inserted.
    """
    metrics_data = fetch_metrics()
    if metrics_data is None:
        print("No metrics fetched; skipping this interval.")
        return

    for room_id, metric in metrics_data.items():
        # Ensure room ID is included in the metric record.
        metric["chat_room"] = room_id

        # Only insert if there is at least one active user.
        if metric.get("active_users", 0) > 0:
            insert_metric_row(metric)
        else:
            print(f"Skipping room {room_id} due to 0 active users.")

if __name__ == "__main__":
    scheduler = BlockingScheduler()

    # Fetch first to empty the metrics from the backend
    _ = fetch_metrics()

    # Schedule flush_metrics_to_bigquery to run every minute
    scheduler.add_job(flush_metrics_to_bigquery, 'interval', minutes=1)
    print("Starting on-premise metrics collector (press Ctrl+C to exit)...")
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("Metrics collector shutting down.")
