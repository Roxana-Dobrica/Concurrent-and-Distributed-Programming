# On-Premise Metrics Collector

This on-premise application periodically collects performance metrics from the chat backend and inserts them into a BigQuery table for analysis. It is designed to aggregate data such as active users, total messages, average latency, error count, and message throughput (messages per second), but only for chat rooms with active users.

## Features

- **Periodic Data Collection**: Polls the chat backend's `/chat/metrics` endpoint every minute.
- **Metrics Aggregation**: Processes metrics by chat room and filters out rooms with no active users.
- **BigQuery Integration**: Inserts aggregated metrics into a BigQuery table using a predefined schema.
- **Logging**: Outputs status messages to the console for easy monitoring and debugging.

## Prerequisites

- **Python 3.7+**
- **Google Cloud SDK** (for BigQuery credentials)
- **Required Libraries**:  
  - `requests`
  - `apscheduler`
  - `google-cloud-bigquery`

You can install the required Python packages using:

```bash
pip install requests apscheduler google-cloud-bigquery
